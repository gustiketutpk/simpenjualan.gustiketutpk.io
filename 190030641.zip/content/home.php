
<div class="judul-content">
	<h1>Beranda</h1>
</div>
<div class="isi-content">
		<div class="judul-home">
			<h1>Selamat Datang di SIM Penjualan</h1>
		</div>
</div>